package br.edu.iftm.service;

import br.edu.iftm.model.Livro;
import br.edu.iftm.DAO.LivroDAO;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class LivroService {

    private LivroDAO livroDAO;

    public LivroService() {
        this.livroDAO = new LivroDAO();
    }

    // Construtor opcional para injeção de dependência
    public LivroService(LivroDAO livroDAO) {
        this.livroDAO = livroDAO;
    }

    public void inserirLivro(Livro livro) {
        List<String> errosValidacao = validarLivro(livro);

        if (verificaErroValidacao(errosValidacao)) return;
        
        livroDAO.inserir(livro);
        System.out.println("Livro inserido com sucesso.");
    }

    public void atualizarLivro(Livro livro) {
        List<String> errosValidacao = validarLivro(livro);
        Livro livroExistente = livroDAO.buscarPorId(livro.getId());

        if (livroExistente == null) {
            System.out.println("Erro de atualização: Livro com ID " + livro.getId() + " não encontrado.");
            return;
        }
        
        if (verificaErroValidacao(errosValidacao)) return;
        
        livroDAO.atualizar(livro);
        System.out.println("Livro atualizado com sucesso.");
    }

    public Livro buscarLivroPorId(int id) {

        Livro livroExistente = livroDAO.buscarPorId(id);
        if (livroExistente == null) {
            System.out.println("Livro com ID " + id + " não encontrado.");
            return null;
        }

        return livroExistente;
    }

    public List<Livro> listarTodosLivros() {
        return livroDAO.listarTodos();

    }

    public void excluirLivro(int id) {

    }

    private List<String> validarLivro(Livro livro) {
        List<String> erros = new ArrayList<>();
        int anoAtual = Calendar.getInstance().get(Calendar.YEAR);

        if (livro.getTitulo() == null || livro.getTitulo().trim().isEmpty()) {
            erros.add("O título do livro não pode ser vazio.");
        }
        if (livro.getAutor() == null || livro.getAutor().trim().isEmpty()) {
            erros.add("O autor do livro não pode ser vazio.");
        }
        if (livro.getIsbn() == null || livro.getIsbn().trim().isEmpty()) {
            erros.add("O ISBN do livro não pode ser vazio.");
        }
        if (livro.getAnoPublicacao() <= 0 || livro.getAnoPublicacao() > anoAtual + 1) {
            erros.add("O ano de publicação é inválido.");
        }
        if (livro.getNumeroPaginas() <= 0) {
            erros.add("O número de páginas deve ser um valor positivo.");
        }

        return erros;
    }
    
    private boolean verificaErroValidacao(List<String> errosValidacao) {
        if (!errosValidacao.isEmpty()) {
            StringBuilder sb = new StringBuilder("Erros de validação:\n");
            for (String erro : errosValidacao) {
                sb.append("- ").append(erro).append("\n");
            }
            System.out.println(sb.toString());
            return true;
        }
        return false;
    }
}
