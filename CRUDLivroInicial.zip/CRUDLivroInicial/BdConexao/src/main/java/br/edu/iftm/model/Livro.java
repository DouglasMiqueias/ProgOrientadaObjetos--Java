package br.edu.iftm.model;

public class Livro {
    private int id;
    private String titulo;
    private String autor;
    private int anoPublicacao;
    private String isbn;
    private int numeroPaginas;

    // Construtor padrão
    public Livro() {
    }

    // Construtor com todos os atributos
    public Livro(int id, String titulo, String autor, int anoPublicacao, String isbn, String genero, String editora, int numeroPaginas) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
        this.isbn = isbn;
        this.numeroPaginas = numeroPaginas;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    // Sobrescrevendo o método toString() para representação textual do objeto
    @Override
    public String toString() {
        return "____________\n"
                + "Livro\n" +
                "id: " + id +
                "\ntitulo: '" + titulo + '\'' +
                "\nautor:: '" + autor + '\'' +
                "\nanoPublicacao: " + anoPublicacao +
                "\nisbn:'" + isbn + '\'' +
                "\nnumeroPaginas: " + numeroPaginas +
                "\n____________\n";
    }
}