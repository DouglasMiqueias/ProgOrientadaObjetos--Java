package br.edu.iftm.util;

import java.sql.*;

public class ConexaoMySQL {

    // Define as informações de conexão com o banco de dados
    // URL de conexão, que contém o endereço do banco, a porta e o nome do banco de dados
    private static final String URL = "jdbc:mysql://localhost:3307/aulaBD";  
    // Usuário do banco de dados
    private static final String USUARIO = "root";  
    // Senha do usuário do banco de dados
    private static final String SENHA = "root";  

    // Método estático que retorna uma conexão com o banco de dados
    public static Connection getConnection() throws SQLException {
        try {
            // Carrega o driver JDBC para o MySQL
            // A classe "com.mysql.cj.jdbc.Driver" é responsável por carregar os recursos necessários para que o Java se conecte ao banco MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Estabelece a conexão com o banco usando as informações fornecidas (URL, usuário e senha)
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            // Caso a classe do driver não seja encontrada, lança uma exceção SQLException
            throw new SQLException(e);
        }
    }
}