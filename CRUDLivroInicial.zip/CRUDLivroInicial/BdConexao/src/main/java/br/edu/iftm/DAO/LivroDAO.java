package br.edu.iftm.DAO;

// Importação das bibliotecas necessárias para o trabalho com SQL e coleções
import br.edu.iftm.model.Livro;
import br.edu.iftm.util.ConexaoMySQL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {

    // Método para inserir um novo livro no banco de dados
    public void inserir(Livro livro) {
        // SQL de inserção no banco de dados
        String sql = "INSERT INTO livros (titulo, autor, ano_publicacao, isbn, numero_paginas) VALUES (?, ?, ?, ?, ?)";
        try {
            Connection conn = ConexaoMySQL.getConnection(); // Obtém a conexão com o banco
            PreparedStatement stmt = conn.prepareStatement(sql); // Prepara o comando SQL
            // Atribui os valores do livro aos parâmetros da query
            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setInt(3, livro.getAnoPublicacao());
            stmt.setString(4, livro.getIsbn());
            stmt.setInt(5, livro.getNumeroPaginas());
            // Executa o comando de inserção no banco
            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("Falha ao inserir livro: " + e.getMessage());
        }
    }

    // Método para buscar um livro no banco de dados pelo ID
    public Livro buscarPorId(int id) {
        String sql = "SELECT * FROM livros WHERE id = ?";
        Livro livro = null; // Cria um novo objeto Livro
        try {
            Connection conn = ConexaoMySQL.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                livro = new Livro();
                livro.setId(rs.getInt("id"));
                livro.setTitulo(rs.getString("titulo"));
                livro.setAutor(rs.getString("autor"));
                livro.setAnoPublicacao(rs.getInt("ano_publicacao"));
                livro.setIsbn(rs.getString("isbn"));
                livro.setNumeroPaginas(rs.getInt("numero_paginas"));
            }
        } catch (Exception e) {
            System.out.println("Falha ao buscar livro: " + e.getMessage());
        }
        return livro;
    }

    // Método para listar todos os livros do banco de dados
    public List<Livro> listarTodos() {
        // SQL para listar todos os livros
        String sql = "SELECT * FROM livros";
        List<Livro> livros = new ArrayList<>(); // Lista para armazenar os livros encontrados
        try {
            Connection conn = ConexaoMySQL.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) { // Para cada livro encontrado
                Livro livro = new Livro(); // Cria um novo objeto Livro
                // Preenche o objeto Livro com os dados retornados da consulta
                livro.setId(rs.getInt("id"));
                livro.setTitulo(rs.getString("titulo"));
                livro.setAutor(rs.getString("autor"));
                livro.setAnoPublicacao(rs.getInt("ano_publicacao"));
                livro.setIsbn(rs.getString("isbn"));
                livro.setNumeroPaginas(rs.getInt("numero_paginas"));
                livros.add(livro); // Adiciona o livro à lista
            }
        } catch (Exception e) {
            System.out.println("Falha ao listar os livros: " + e.getMessage());
        }
        return livros;
    }

    // Método para atualizar as informações de um livro no banco de dados
    public void atualizar(Livro livro) {
        //código para atualizar o livro
    }

    // Método para excluir um livro do banco de dados pelo ID
    public void excluir(int id) {

    }
}
