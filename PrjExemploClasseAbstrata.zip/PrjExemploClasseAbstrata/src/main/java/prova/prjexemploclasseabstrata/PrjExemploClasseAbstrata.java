/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package prova.prjexemploclasseabstrata;

import prova.prjexemploclasseabstrata.models.Circulo;
import prova.prjexemploclasseabstrata.models.FormaGeometrica;
import prova.prjexemploclasseabstrata.models.Retangulo;

/**
 *
 * @author IFTM
 */
public class PrjExemploClasseAbstrata {

    public static void main(String[] args) 
    {
        FormaGeometrica r = new Retangulo("Retangulo azul", 10, 5);
        
        FormaGeometrica c = new Circulo("Circulo Verde", 7);
        
        System.out.println("Nome da forma: " + r.getNome());
        System.out.println("Area: " + r.calcularArea());
        System.out.println("-------");
        
        System.out.println("Nome da forma: " + c.getNome());
        System.out.println("Area: " + c.calcularArea());
        System.out.println("-------");
        
        
    }
}
