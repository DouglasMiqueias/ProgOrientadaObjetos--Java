package com.mycompany.prjcadastroveiculos.menus;

import com.mycompany.prjcadastroveiculos.classes.Moto;
import java.util.Scanner;

public class MenuPrincipal 
{
    public static void executar()
    {
        Scanner sc = new Scanner(System.in);
        int opcao;
        
        do
        {
            System.out.println("== MENU PRINCIPAL ==");
            System.out.println("1- CADASTRAR CARROS");
            System.out.println("1- CADASTRAR MOTOS");
            System.out.println("2- LISTAR VEICULOS");
            System.out.println("0- ENCERRAR PROGRAMA");
            opcao = sc.nextInt();
            sc.nextLine();
            
            switch(opcao)
            {
                case 1 ->{
                    Moto m = new Moto();
                    
                    System.out.println("Informe o id do veiculo");
                    m.setId(sc.nextInt());
                    System.out.println("Informe o ano da moto: ");
                    m.setAno(sc.nextInt());
                    System.out.println("Informe o chassi da moto: ");
                    m.setChassi(sc.nextLine());
                    System.out.println("Informe a cilindrada da moto: ");
                    m.setCilindradas(sc.nextInt());
                    System.out.println("Informe a cor do veiculo:");
                    m.setCor(sc.nextLine());
                    System.out.println("");
                    m.setMarca("Informe a marca do veiculo:");
                    m.setMarca(sc.nextLine());
                }
                case 0 ->{
                    opcao = 0;
                }
            }         
        }while(opcao != 0);
    }
    
}
