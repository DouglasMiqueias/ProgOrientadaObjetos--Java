package com.poo.prjexemplolistas;

import com.poo.prjexemplolistas.objetos.Aluno;
import com.poo.prjexemplolistas.objetos.Disciplina;
import com.poo.prjexemplolistas.objetos.Professor;
import com.poo.prjexemplolistas.util.MostrarDados;
import java.util.ArrayList;
import java.util.List;

public class PrjExemploListas {

    public static void main(String[] args) {
        Disciplina disciplina = new Disciplina();
        Aluno aluno = new Aluno();
        Aluno aluno2 = new Aluno();
        Professor professor = new Professor();
        
        professor.setNome("professor teste");
        professor.setGraduacao("ADS");
        professor.setCpf("1234565789-78");
        
        aluno.setNome("Aluno teste 1");
        aluno.setCpf("789456231");
        aluno.setDataNascimento("14/09/2004");
        
        aluno2.setNome("Aluno teste 2");
        aluno2.setCpf("111333555-78");
        aluno2.setDataNascimento("17/02/2018");
        
        List<Aluno> lstAlunos = new ArrayList<>();
        lstAlunos.add(aluno);
        lstAlunos.add(aluno2);
        
        disciplina.setNome("POO I");
        disciplina.setPeriodo(3);
        disciplina.setCargaHoraria(120);
        disciplina.setProfessor(professor);
        disciplina.setLstAlunos(lstAlunos);
        
        MostrarDados md = new MostrarDados();
        md.mostrar(disciplina);
    }
}
