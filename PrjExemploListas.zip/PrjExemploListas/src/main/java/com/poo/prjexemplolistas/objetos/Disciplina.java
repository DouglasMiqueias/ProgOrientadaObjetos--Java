package com.poo.prjexemplolistas.objetos;

import java.util.List;

public class Disciplina
{
    private String nome;
    private float cargaHoraria;
    private int periodo;
    private Professor professor;
    private List<Aluno> lstAlunos;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(float cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public List<Aluno> getLstAlunos() {
        return lstAlunos;
    }

    public void setLstAlunos(List<Aluno> lstAlunos) {
        this.lstAlunos = lstAlunos;
    }
    
    
    
    
    
    
    
    
}
