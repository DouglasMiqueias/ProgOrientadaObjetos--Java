package com.poo.prjexemplolistas.util;

import com.poo.prjexemplolistas.objetos.Aluno;
import com.poo.prjexemplolistas.objetos.Disciplina;

public class MostrarDados
{

    public void mostrar(Disciplina d)
    {
        System.out.println("Nome: "+ d.getNome());
        System.out.println("Periodo: "+ d.getPeriodo());
        System.out.println("Carga Horaria: "+ d.getCargaHoraria());
        
        System.out.println("Professor: "+d.getProfessor().getNome());
        
        System.out.println("*****************************");
        for(Aluno a : d.getLstAlunos())
        {
            System.out.println("Nome: " + a.getNome());
            System.out.println("Data Nascimento" + a.getDataNascimento());
            System.out.println("CPF: " + a.getCpf());
            System.out.println("################################");
            
        }
        
    } 
}
