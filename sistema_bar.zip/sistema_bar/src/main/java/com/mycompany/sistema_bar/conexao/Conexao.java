/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author mique
 */
public class Conexao 
{
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_bar";
    private static final String USUARIO = "douglas";
    private static final String SENHA = "Miqueias@13579";
    
    public static Connection conectar(){
        try{
            return DriverManager.getConnection(URL,USUARIO,SENHA);
        } catch (SQLException e){
            System.out.println("Erro ao conector com o Banco de Dados: " + e.getMessage());
            return null;
        }
    }
}