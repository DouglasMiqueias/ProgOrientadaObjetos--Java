/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.service;

/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.dao.PedidoDAO;
import com.mycompany.sistema_bar.model.Pedido;

import java.util.List;
public class PedidoService 
{
     private PedidoDAO dao = new PedidoDAO();

    public boolean salvar(Pedido pedido) {
        if (!validar(pedido)) return false;
        dao.inserir(pedido);
        return true;
    }

    public List<Pedido> listar() {
        return dao.listar();
    }

    public boolean atualizar(Pedido pedido) {
        if (!validar(pedido)) return false;
        dao.atualizar(pedido);
        return true;
    }

    public void deletar(int id) {
        dao.deletar(id);
    }

    private boolean validar(Pedido pedido) {
        if (pedido.getClienteId() <= 0) {
            System.out.println("❌ Cliente inválido.");
            return false;
        }
        if (pedido.getFuncionarioId() <= 0) {
            System.out.println("❌ Funcionário inválido.");
            return false;
        }
        if (pedido.getData() == null) {
            System.out.println("❌ Data do pedido é obrigatória.");
            return false;
        }
        if (pedido.getTotal() < 0) {
            System.out.println("❌ Total do pedido não pode ser negativo.");
            return false;
        }
        return true;
    }
    
}
