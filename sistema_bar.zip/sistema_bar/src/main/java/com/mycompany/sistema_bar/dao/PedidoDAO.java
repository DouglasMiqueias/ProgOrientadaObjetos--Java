/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.dao;
/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.conexao.Conexao;
import com.mycompany.sistema_bar.model.Pedido;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class PedidoDAO 
{
     public void inserir(Pedido pedido) {
        String sql = "INSERT INTO Pedido (cliente_id, funcionario_id, data, total) VALUES (?, ?, ?, ?)";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, pedido.getClienteId());
            stmt.setInt(2, pedido.getFuncionarioId());
            stmt.setTimestamp(3, Timestamp.valueOf(pedido.getData()));
            stmt.setDouble(4, pedido.getTotal());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir pedido: " + e.getMessage());
        }
    }

    public List<Pedido> listar() {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM Pedido";

        try (Connection conn = Conexao.conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Pedido p = new Pedido();
                p.setId(rs.getInt("id"));
                p.setClienteId(rs.getInt("cliente_id"));
                p.setFuncionarioId(rs.getInt("funcionario_id"));
                p.setData(rs.getTimestamp("data").toLocalDateTime());
                p.setTotal(rs.getDouble("total"));
                pedidos.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar pedidos: " + e.getMessage());
        }

        return pedidos;
    }

    public void atualizar(Pedido pedido) {
        String sql = "UPDATE Pedido SET cliente_id = ?, funcionario_id = ?, data = ?, total = ? WHERE id = ?";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, pedido.getClienteId());
            stmt.setInt(2, pedido.getFuncionarioId());
            stmt.setTimestamp(3, Timestamp.valueOf(pedido.getData()));
            stmt.setDouble(4, pedido.getTotal());
            stmt.setInt(5, pedido.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar pedido: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM Pedido WHERE id = ?";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao excluir pedido: " + e.getMessage());
        }
    }
    
}
