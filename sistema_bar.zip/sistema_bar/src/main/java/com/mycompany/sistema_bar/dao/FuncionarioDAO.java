/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.dao;
import com.mycompany.sistema_bar.conexao.Conexao;
import com.mycompany.sistema_bar.model.Funcionario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author mique
 */
public class FuncionarioDAO 
{
    public void inserir(Funcionario funcionario) {
        String sql = "INSERT INTO Funcionario (nome, cpf, funcao, salario_hora) VALUES (?, ?, ?, ?)";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getCpf());
            stmt.setString(3, funcionario.getFuncao());
            stmt.setDouble(4, funcionario.getSalario_hora());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir funcionário: " + e.getMessage());
        }
    }

    public List<Funcionario> listar() {
        List<Funcionario> funcionarios = new ArrayList<>();
        String sql = "SELECT * FROM Funcionario";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Funcionario f = new Funcionario();
                f.setId(rs.getInt("id"));
                f.setNome(rs.getString("nome"));
                f.setCpf(rs.getString("cpf"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario_hora(rs.getDouble("salario_hora"));
                funcionarios.add(f);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar funcionários: " + e.getMessage());
        }

        return funcionarios;
    }

    public void atualizar(Funcionario funcionario) {
        String sql = "UPDATE Funcionario SET nome = ?, cpf = ?, funcao = ?, salario_hora = ? WHERE id = ?";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getCpf());
            stmt.setString(3, funcionario.getFuncao());
            stmt.setDouble(4, funcionario.getSalario_hora());
            stmt.setInt(5, funcionario.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar funcionário: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM Funcionario WHERE id = ?";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {  
            System.out.println("Erro ao excluir funcionario: " + e.getMessage());
        }
    }
    
}
