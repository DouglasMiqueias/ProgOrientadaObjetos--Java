/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.model;

/**
 *
 * @author mique
 */

import java.time.LocalDateTime;
public class Pedido
{
    private int id;
    private int clienteId;
    private int funcionarioId;
    private LocalDateTime data;
    private double total;

    public Pedido() {
    }

    public Pedido(int id, int clienteId, int funcionarioId, LocalDateTime data, double total) {
        this.id = id;
        this.clienteId = clienteId;
        this.funcionarioId = funcionarioId;
        this.data = data;
        this.total = total;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public int getFuncionarioId() {
        return funcionarioId;
    }

    public void setFuncionarioId(int funcionarioId) {
        this.funcionarioId = funcionarioId;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    
}
