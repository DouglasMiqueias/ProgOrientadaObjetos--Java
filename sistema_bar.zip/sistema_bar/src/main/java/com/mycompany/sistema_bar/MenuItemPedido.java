/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar;

import java.util.Scanner;

/**
 *
 * @author mique
 */
public class MenuItemPedido 
{
    public static void executar(Scanner scanner){
        System.out.println("Item pedido");
    }
    
}
