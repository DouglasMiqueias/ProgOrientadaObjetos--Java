/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.service;

/**
 *
 * @author mique
 */

import com.mycompany.sistema_bar.dao.ItemPedidoDAO;
import com.mycompany.sistema_bar.dao.PedidoDAO;
import com.mycompany.sistema_bar.dao.ProdutoDAO;
import com.mycompany.sistema_bar.model.ItemPedido;

import java.util.List;

public class ItemPedidoService
{
    private ItemPedidoDAO dao = new ItemPedidoDAO();
    private PedidoDAO pedidoDAO = new PedidoDAO();
    private ProdutoDAO produtoDAO = new ProdutoDAO();

    public boolean salvar(ItemPedido item) {
        if (!validar(item)) return false;
        dao.inserir(item);
        return true;
    }

    public List<ItemPedido> listarPorPedido(int pedidoId) {
        return dao.listarPorPedido(pedidoId);
    }

    public boolean atualizar(ItemPedido item) {
        if (!validar(item)) return false;
        dao.atualizar(item);
        return true;
    }

    public void deletar(int id) {
        dao.deletar(id);
    }

    private boolean validar(ItemPedido item) {
        if (item.getPedidoId() <= 0) {
            System.out.println("❌ Pedido inválido.");
            return false;
        }
        if (item.getProdutoId() <= 0) {
            System.out.println("❌ Produto inválido.");
            return false;
        }
        if (item.getQuantidade() <= 0) {
            System.out.println("❌ Quantidade deve ser maior que zero.");
            return false;
        }
        if (item.getPrecoUnitario() <= 0) {
            System.out.println("❌ Preço unitário inválido.");
            return false;
        }
        return true;
    }

}
