/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.service;

import com.mycompany.sistema_bar.dao.FuncionarioDAO;
import com.mycompany.sistema_bar.model.Funcionario;

import java.util.List;
/**
 *
 * @author mique
 */
public class FuncionarioService 
{
    private FuncionarioDAO dao = new FuncionarioDAO();

    public boolean salvar(Funcionario f) {
        if (!validar(f)) return false;
        dao.inserir(f);
        return true;
    }

    public List<Funcionario> listar() {
        return dao.listar();
    }

    public boolean atualizar(Funcionario f) {
        if (!validar(f)) return false;
        dao.atualizar(f);
        return true;
    }

    public void deletar(int id) {
        dao.deletar(id);
    }

    private boolean validar(Funcionario f) {
        if (f.getNome() == null || f.getNome().isEmpty()) {
            System.out.println("❌ Nome é obrigatório.");
            return false;
        }
        if (f.getCpf() == null || f.getCpf().isEmpty()) {
            System.out.println("❌ CPF é obrigatório.");
            return false;
        }
        if (f.getFuncao() == null || f.getFuncao().isEmpty()) {
            System.out.println("❌ Função é obrigatória.");
            return false;
        }
        if (f.getSalario_hora()<= 0) {
            System.out.println("❌ Salário por hora deve ser maior que zero.");
            return false;
        }
        return true;
    }
    
}
