package com.mycompany.sistema_bar.dao;

import com.mycompany.sistema_bar.conexao.Conexao;
import com.mycompany.sistema_bar.model.Produto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    public void inserir(Produto produto) {
        String sql = "INSERT INTO Produto (nome, tipo, preco, quantidade_estoque) VALUES (?,?,?,?)";

        try (Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getTipo());
            stmt.setDouble(3, produto.getPreco());
            stmt.setInt(4, produto.getQuantidade_estoque()); // Nome correto do getter
            stmt.executeUpdate(); // ESSENCIAL
        } catch (SQLException e) {
            System.out.println("Erro ao inserir produto: " + e.getMessage());
        }
    }

    public List<Produto> listar() {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM Produto";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Produto p = new Produto();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setTipo(rs.getString("tipo"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                produtos.add(p);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
        return produtos;
    }
    
    public void atualizar(Produto produto){
        String sql = "UPDATE Produto SET nome = ?, tipo = ?, preco = ?, quantidade_estoque = ? WHERE ID = ?";
        
        try(Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getTipo());
            stmt.setDouble(3, produto.getPreco());
            stmt.setInt(4, produto.getQuantidade_estoque());
            stmt.setInt(5, produto.getId());
            stmt.executeUpdate();            
        }catch(SQLException e){
            System.out.println("Erro ao atualizar produto" + e.getMessage());
        }
    }
    
    public void deletar(int id){
        String sql = "DELETE FROM Produto WHERE id = ?";
        try(Connection conn = Conexao.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)){
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao deletar produto: " + e.getMessage() );
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
