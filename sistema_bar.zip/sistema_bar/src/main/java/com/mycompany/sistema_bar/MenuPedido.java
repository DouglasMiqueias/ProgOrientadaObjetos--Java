/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar;

/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.model.Pedido;
import com.mycompany.sistema_bar.service.PedidoService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

public class MenuPedido 
{
     public static void executar(Scanner scanner) {
        PedidoService service = new PedidoService();
        int opcao;

        do {
            System.out.println("\n====== MENU PEDIDOS ======");
            System.out.println("1. Cadastrar Pedido");
            System.out.println("2. Listar Pedidos");
            System.out.println("3. Atualizar Pedido");
            System.out.println("4. Remover Pedido");
            System.out.println("0. Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> {
                    Pedido pedido = new Pedido();
                    System.out.print("ID do Cliente: ");
                    pedido.setClienteId(scanner.nextInt());
                    System.out.print("ID do Funcionário: ");
                    pedido.setFuncionarioId(scanner.nextInt());
                    System.out.print("Total do Pedido: ");
                    pedido.setTotal(scanner.nextDouble());
                    pedido.setData(LocalDateTime.now()); // define data atual
                    scanner.nextLine();

                    if (service.salvar(pedido)) {
                        System.out.println("✅ Pedido cadastrado com sucesso!");
                    }
                }

                case 2 -> {
                    List<Pedido> pedidos = service.listar();
                    if (pedidos.isEmpty()) {
                        System.out.println("⚠️ Nenhum pedido cadastrado.");
                    } else {
                        System.out.println("\n--- Lista de Pedidos ---");
                        for (Pedido p : pedidos) {
                            System.out.printf("ID: %d | Cliente ID: %d | Funcionário ID: %d | Data: %s | Total: %.2f\n",
                                    p.getId(), p.getClienteId(), p.getFuncionarioId(), p.getData(), p.getTotal());
                        }
                    }
                }

                case 3 -> {
                    System.out.print("ID do pedido a atualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    Pedido pedido = new Pedido();
                    pedido.setId(id);
                    System.out.print("Novo ID do Cliente: ");
                    pedido.setClienteId(scanner.nextInt());
                    System.out.print("Novo ID do Funcionário: ");
                    pedido.setFuncionarioId(scanner.nextInt());
                    System.out.print("Novo Total: ");
                    pedido.setTotal(scanner.nextDouble());
                    pedido.setData(LocalDateTime.now()); // pode manter ou permitir digitação
                    scanner.nextLine();

                    if (service.atualizar(pedido)) {
                        System.out.println("✅ Pedido atualizado com sucesso!");
                    }
                }

                case 4 -> {
                    System.out.print("ID do pedido a remover: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    service.deletar(id);
                    System.out.println("🗑️ Pedido removido com sucesso.");
                }

                case 0 -> System.out.println("Voltando ao menu principal...");

                default -> System.out.println("❌ Opção inválida.");
            }

        } while (opcao != 0);
    }
}
