/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.service;
/**
 *
 * @author mique
 */

import com.mycompany.sistema_bar.dao.ProdutoDAO;
import com.mycompany.sistema_bar.model.Produto;

import java.util.List;


public class ProdutoService {
     private ProdutoDAO dao = new ProdutoDAO();

    public boolean salvar(Produto produto) {
        if (!validar(produto)) return false;
        dao.inserir(produto);
        return true;
    }

    public List<Produto> listar() {
        return dao.listar();
    }

    public boolean atualizar(Produto produto) {
        if (!validar(produto)) return false;
        dao.atualizar(produto);
        return true;
    }

    public void deletar(int id) {
        dao.deletar(id);
    }

    private boolean validar(Produto produto) {
        if (produto.getNome() == null || produto.getNome().isEmpty()) {
            System.out.println("❌ Nome do produto é obrigatório.");
            return false;
        }
        if (produto.getTipo() == null || produto.getTipo().isEmpty()) {
            System.out.println("❌ Tipo do produto é obrigatório.");
            return false;
        }
        if (produto.getPreco() <= 0) {
            System.out.println("❌ Preço deve ser maior que zero.");
            return false;
        }
        if (produto.getQuantidade_estoque()< 0) {
            System.out.println("❌ Quantidade em estoque não pode ser negativa.");
            return false;
        }
        return true;
    }
}
