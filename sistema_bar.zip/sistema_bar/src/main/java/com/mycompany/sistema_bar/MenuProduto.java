/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar;

/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.model.Produto;
import com.mycompany.sistema_bar.service.ProdutoService;

import java.util.List;
import java.util.Scanner;

public class MenuProduto 
{
     public static void executar(Scanner scanner) {
        ProdutoService service = new ProdutoService();
        int opcao;

        do {
            System.out.println("\n====== MENU PRODUTOS ======");
            System.out.println("1. Cadastrar Produto");
            System.out.println("2. Listar Produtos");
            System.out.println("3. Atualizar Produto");
            System.out.println("4. Remover Produto");
            System.out.println("0. Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // limpa o buffer

            switch (opcao) {
                case 1 -> {
                    Produto produto = new Produto();
                    System.out.print("Nome: ");
                    produto.setNome(scanner.nextLine());
                    System.out.print("Tipo: ");
                    produto.setTipo(scanner.nextLine());
                    System.out.print("Preço: ");
                    produto.setPreco(scanner.nextDouble());
                    System.out.print("Quantidade em Estoque: ");
                    produto.setQuantidade_estoque(scanner.nextInt());
                    scanner.nextLine(); // limpa o buffer

                    if (service.salvar(produto)) {
                        System.out.println("✅ Produto cadastrado com sucesso!");
                    }
                }

                case 2 -> {
                    List<Produto> produtos = service.listar();
                    if (produtos.isEmpty()) {
                        System.out.println("⚠️ Nenhum produto cadastrado.");
                    } else {
                        System.out.println("\n--- Lista de Produtos ---");
                        for (Produto p : produtos) {
                            System.out.printf("ID: %d | Nome: %s | Tipo: %s | Preço: %.2f | Estoque: %d\n",
                                    p.getId(), p.getNome(), p.getTipo(), p.getPreco(), p.getQuantidade_estoque());
                        }
                    }
                }

                case 3 -> {
                    System.out.print("ID do produto a atualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    Produto produto = new Produto();
                    produto.setId(id);
                    System.out.print("Novo nome: ");
                    produto.setNome(scanner.nextLine());
                    System.out.print("Novo tipo: ");
                    produto.setTipo(scanner.nextLine());
                    System.out.print("Novo preço: ");
                    produto.setPreco(scanner.nextDouble());
                    System.out.print("Nova quantidade em estoque: ");
                    produto.setQuantidade_estoque(scanner.nextInt());
                    scanner.nextLine();

                    if (service.atualizar(produto)) {
                        System.out.println("✅ Produto atualizado com sucesso!");
                    }
                }

                case 4 -> {
                    System.out.print("ID do produto a remover: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    service.deletar(id);
                    System.out.println("🗑️ Produto removido com sucesso.");
                }

                case 0 -> System.out.println("Voltando ao menu principal...");

                default -> System.out.println("❌ Opção inválida.");
            }

        } while (opcao != 0);
    }
}
