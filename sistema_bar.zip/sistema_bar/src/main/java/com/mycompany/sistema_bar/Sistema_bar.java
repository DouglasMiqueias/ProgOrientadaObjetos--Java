/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_bar;

/**
 *
 * @author mique
 */
import java.util.Scanner;

public class Sistema_bar {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Gerenciar Clientes");
            System.out.println("2. Gerenciar Produtos");
            System.out.println("3. Gerenciar Funcionários");
            System.out.println("4. Gerenciar Pedidos");
            System.out.println("5. Gerenciar Itens de Pedido");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            switch (opcao) {
                case 1:
                    MenuCliente.executar(scanner);
                    break;
                case 2:
                    MenuProduto.executar(scanner);
                    break;
                case 3:
                    MenuFuncionario.executar(scanner);
                    break;
                case 4:
                    MenuPedido.executar(scanner);
                    break;
                case 5:
                    MenuItemPedido.executar(scanner);
                    break;
                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}