/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar;

/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.model.Funcionario;
import com.mycompany.sistema_bar.service.FuncionarioService;

import java.util.List;
import java.util.Scanner;

public class MenuFuncionario {

    public static void executar(Scanner scanner) {
        FuncionarioService service = new FuncionarioService();
        int opcao;

        do {
            System.out.println("\n====== MENU FUNCIONÁRIOS ======");
            System.out.println("1. Cadastrar Funcionário");
            System.out.println("2. Listar Funcionários");
            System.out.println("3. Atualizar Funcionário");
            System.out.println("4. Remover Funcionário");
            System.out.println("0. Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // limpa o buffer

            switch (opcao) {
                case 1 -> {
                    Funcionario funcionario = new Funcionario();
                    System.out.print("Nome: ");
                    funcionario.setNome(scanner.nextLine());
                    System.out.print("CPF: ");
                    funcionario.setCpf(scanner.nextLine());
                    System.out.print("Função: ");
                    funcionario.setFuncao(scanner.nextLine());
                    System.out.print("Salário por hora: ");
                    funcionario.setSalario_hora(scanner.nextDouble());
                    scanner.nextLine();

                    if (service.salvar(funcionario)) {
                        System.out.println("✅ Funcionário cadastrado com sucesso!");
                    }
                }

                case 2 -> {
                    List<Funcionario> funcionarios = service.listar();
                    if (funcionarios.isEmpty()) {
                        System.out.println("⚠️ Nenhum funcionário cadastrado.");
                    } else {
                        System.out.println("\n--- Lista de Funcionários ---");
                        for (Funcionario f : funcionarios) {
                            System.out.printf("ID: %d | Nome: %s | CPF: %s | Função: %s | Salário/Hora: %.2f\n",
                                    f.getId(), f.getNome(), f.getCpf(), f.getFuncao(), f.getSalario_hora());
                        }
                    }
                }

                case 3 -> {
                    System.out.print("ID do funcionário a atualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    Funcionario funcionario = new Funcionario();
                    funcionario.setId(id);
                    System.out.print("Novo nome: ");
                    funcionario.setNome(scanner.nextLine());
                    System.out.print("Novo CPF: ");
                    funcionario.setCpf(scanner.nextLine());
                    System.out.print("Nova função: ");
                    funcionario.setFuncao(scanner.nextLine());
                    System.out.print("Novo salário por hora: ");
                    funcionario.setSalario_hora(scanner.nextDouble());
                    scanner.nextLine();

                    if (service.atualizar(funcionario)) {
                        System.out.println("✅ Funcionário atualizado com sucesso!");
                    }
                }

                case 4 -> {
                    System.out.print("ID do funcionário a remover: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    service.deletar(id);
                    System.out.println("🗑️ Funcionário removido com sucesso.");
                }

                case 0 -> System.out.println("Voltando ao menu principal...");

                default -> System.out.println("❌ Opção inválida.");
            }

        } while (opcao != 0);
    }
}
