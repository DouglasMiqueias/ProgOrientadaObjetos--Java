/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar;

/**
 *
 * @author mique
 */
import com.mycompany.sistema_bar.model.Cliente;
import com.mycompany.sistema_bar.service.ClienteService;

import java.util.List;
import java.util.Scanner;

public class MenuCliente {
    
  public static void executar(Scanner scanner) {
        ClienteService service = new ClienteService();
        int opcao;

        do {
            System.out.println("\n====== MENU CLIENTES ======");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Atualizar Cliente");
            System.out.println("4. Remover Cliente");
            System.out.println("0. Voltar ao menu principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa buffer

            switch (opcao) {
                case 1 -> {
                    Cliente cliente = new Cliente();
                    System.out.print("Nome: ");
                    cliente.setNome(scanner.nextLine());
                    System.out.print("Telefone: ");
                    cliente.setTelefone(scanner.nextLine());
                    System.out.print("CPF: ");
                    cliente.setCpf(scanner.nextLine());

                    if (service.salvar(cliente)) {
                        System.out.println("✅ Cliente cadastrado com sucesso!");
                    }
                }

                case 2 -> {
                    List<Cliente> clientes = service.listar();
                    if (clientes.isEmpty()) {
                        System.out.println("⚠️ Nenhum cliente cadastrado.");
                    } else {
                        System.out.println("\n--- Lista de Clientes ---");
                        for (Cliente c : clientes) {
                            System.out.printf("ID: %d | Nome: %s | Telefone: %s | CPF: %s\n",
                                    c.getId(), c.getNome(), c.getTelefone(), c.getCpf());
                        }
                    }
                }

                case 3 -> {
                    System.out.print("ID do cliente a atualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Limpa buffer
                    Cliente cliente = new Cliente();
                    cliente.setId(id);
                    System.out.print("Novo nome: ");
                    cliente.setNome(scanner.nextLine());
                    System.out.print("Novo telefone: ");
                    cliente.setTelefone(scanner.nextLine());
                    System.out.print("Novo CPF: ");
                    cliente.setCpf(scanner.nextLine());

                    if (service.atualizar(cliente)) {
                        System.out.println("✅ Cliente atualizado com sucesso!");
                    }
                }

                case 4 -> {
                    System.out.print("ID do cliente a remover: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    service.deletar(id);
                    System.out.println("🗑️ Cliente removido com sucesso.");
                }

                case 0 -> System.out.println("Retornando ao menu principal...");

                default -> System.out.println("❌ Opção inválida.");
            }

        } while (opcao != 0);
    }
}
