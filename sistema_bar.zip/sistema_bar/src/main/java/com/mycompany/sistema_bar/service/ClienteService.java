/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bar.service;

import com.mycompany.sistema_bar.dao.ClienteDAO;
import com.mycompany.sistema_bar.model.Cliente;

import java.util.List;

/**
 *
 * @author mique
 */
public class ClienteService 
{
    private ClienteDAO dao = new ClienteDAO();

    public boolean salvar(Cliente cliente) {
        if (!validar(cliente)) return false;
        dao.inserir(cliente);
        return true;
    }

    public List<Cliente> listar() {
        return dao.listar();
    }

    public boolean atualizar(Cliente cliente) {
        if (!validar(cliente)) return false;
        dao.atualizar(cliente);
        return true;
    }

    public void deletar(int id) {
        dao.deletar(id);
    }

    private boolean validar(Cliente cliente) {
        if (cliente.getNome() == null || cliente.getNome().isEmpty()) {
            System.out.println("❌ Nome é obrigatório.");
            return false;
        }
        if (cliente.getCpf() == null || cliente.getCpf().isEmpty()) {
            System.out.println("❌ CPF é obrigatório.");
            return false;
        }
        if (cliente.getTelefone() == null || cliente.getTelefone().isEmpty()) {
            System.out.println("❌ Telefone é obrigatório.");
            return false;
        }
        return true;
    }
    
}
