/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjcadastroveiculos;

import com.mycompany.prjcadastroveiculos.menus.MenuPrincipal;

/**
 *
 * @author mique
 */
public class PrjCadastroVeiculos {

    public static void main(String[] args) {
        MenuPrincipal.executar();
    }
}
