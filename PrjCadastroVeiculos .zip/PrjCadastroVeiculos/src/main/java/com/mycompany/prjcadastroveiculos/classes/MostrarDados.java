
package com.mycompany.prjcadastroveiculos.classes;

/**
 *
 * @author mique
 */
public class MostrarDados 
{
    public void mostrar(Moto m)
    {
        System.out.println("");
    }
    
    public void mostrar(Carro c)
    {
        System.out.println("");
    }
    
}
