package com.mycompany.prjcadastroveiculos.menus;

import com.mycompany.prjcadastroveiculos.arquivos.LerArquivoCarro;
import com.mycompany.prjcadastroveiculos.arquivos.LerArquivoMoto;
import java.util.List;
import java.util.Scanner;

public class MenuListar 
{
    public static void executar()
    {
    Scanner sc = new Scanner(System.in);
        int opcao;
        
        do {
            System.out.println("== MENU LISTAR ==");
            System.out.println("1- LISTAR CARROS");
            System.out.println("2- LISTAR MOTOS");
            System.out.println("3- LISTAR TODOS OS VEICULOS");
            System.out.println("0- ENCERRAR PROGRAMA");
            System.out.println("ESCOLHA: ");
                    
            opcao = sc.nextInt();
            sc.nextLine();
            
            switch(opcao)
            {
                case 1 ->
                {
                    LerArquivoCarro arq = new LerArquivoCarro();
                    List<String> lstDados = arq.ler();
        
                    for(String linha : lstDados){
                    System.out.println(linha);
                }
                   
                    
                }
                case 2 ->
                {
                     LerArquivoMoto arq = new LerArquivoMoto();
                     List<String> lstDados = arq.ler();
        
                    for(String linha : lstDados){
                    System.out.println(linha);
                    }
                }
                case 0 ->{
                    opcao = 0;
                }
            }         
        }while(opcao != 0);
    }
}

   
