/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcadastroveiculos.arquivos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author IFTM
 */
public class EscreverArquivoMoto 
{
    public void escrever(String listaMotos)
    {
        try 
        {
            File f = new File("c:\\ListaMotos.txt");
            
            FileWriter fw = new FileWriter(f, true);
            
            PrintWriter pw = new PrintWriter(fw);
            
            pw.println(listaMotos);
            
            fw.close();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
