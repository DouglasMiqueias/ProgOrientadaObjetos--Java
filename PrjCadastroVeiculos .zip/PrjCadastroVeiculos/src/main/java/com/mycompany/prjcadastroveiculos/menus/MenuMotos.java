package com.mycompany.prjcadastroveiculos.menus;

import com.mycompany.prjcadastroveiculos.arquivos.EscreverArquivoMoto;
import com.mycompany.prjcadastroveiculos.classes.Moto;
import java.util.Scanner;

public class MenuMotos 
{
    public static void executar()
    {
        Scanner sc = new Scanner(System.in);
         Moto m = new Moto();
                    
                    System.out.println("Informe o id do veiculo");
                    m.setId(sc.nextInt());
                    sc.nextLine();
                    System.out.println("Informe a marca da moto: ");
                    m.setMarca(sc.nextLine());
                    System.out.println("Informe a cilindrada da moto: ");
                    m.setCilindradas(sc.nextInt());
                    sc.nextLine();
                    System.out.println("informe o modelo da moto: ");
                    m.setModelo(sc.nextLine());
                    System.out.println("Informe o tipo de partida: ");
                    m.setTipoPartida(sc.nextLine());
                    
                    String dados = m.getId() + ";" + m.getMarca() + ";" + m.getCilindradas() + ";" +m.getModelo() + ";";
                    
                    EscreverArquivoMoto arq = new EscreverArquivoMoto();
                    arq.escrever(dados);
                    
                    
    }
    
}
