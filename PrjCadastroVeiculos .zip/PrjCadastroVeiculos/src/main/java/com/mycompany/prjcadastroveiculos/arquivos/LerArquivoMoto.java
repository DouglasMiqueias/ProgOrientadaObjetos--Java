/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcadastroveiculos.arquivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author IFTM
 */
public class LerArquivoMoto 
{
    public List<String> ler()
    {
        List<String> dados = new ArrayList();
        try
        {
            File f = new File("c:\\ListaMotos.txt");
            
            FileReader fr = new FileReader(f);
            
            BufferedReader br = new BufferedReader(fr);
            
            while(br.ready())
            {
                dados.add(br.readLine());
            }
            fr.close();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        return dados;
    }
    
}
