package prova.prj_dmam_cadastroempresas;

import prova.prj_dmam_cadastroempresas.menu.MenuPrincipal;

public class Prj_Dmam_CadastroEmpresas {

    public static void main(String[] args) 
    {
        MenuPrincipal.executar();
    }
}
