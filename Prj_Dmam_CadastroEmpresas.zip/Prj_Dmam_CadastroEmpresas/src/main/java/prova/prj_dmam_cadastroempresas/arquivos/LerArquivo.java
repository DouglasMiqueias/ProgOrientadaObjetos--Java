package prova.prj_dmam_cadastroempresas.arquivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LerArquivo 
{
    public BufferedReader ler(String arquivo)
    {
        BufferedReader br = null;
        try{
            File f = new File(arquivo);
    
            if(f.exists())
            {
                FileReader fr = new FileReader(f);
                
                br = new BufferedReader(fr);
            }
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        return br;
    }
    
}
