package prova.prj_dmam_cadastroempresas.arquivos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EscreverArquivo 
{
    public void escrever(String arquivo, String texto, boolean manter)
    {
        try
        {
            File f = new File(arquivo);
            
            FileWriter fw = new FileWriter(f, manter);
            
            PrintWriter pw = new PrintWriter(fw);
            
            pw.println(texto);
            
            fw.close();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
}
