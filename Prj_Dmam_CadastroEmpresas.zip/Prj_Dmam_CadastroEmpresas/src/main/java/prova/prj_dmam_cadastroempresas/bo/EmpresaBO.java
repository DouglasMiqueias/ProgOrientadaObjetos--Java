package prova.prj_dmam_cadastroempresas.bo;

import java.lang.foreign.PaddingLayout;
import java.util.List;
import prova.prj_dmam_cadastroempresas.dao.EmpresaDAO;
import prova.prj_dmam_cadastroempresas.objetos.Empresa;
import prova.prj_dmam_cadastroempresas.objetos.Pessoa;

public class EmpresaBO 
{
    EmpresaDAO eDAO;
    
    public EmpresaBO()
    {
        eDAO = new EmpresaDAO();
    }
    
    public void salvarEmpresa(Empresa e)
    {
        if(e.getCNPJ().trim().length() == 18)
        {
            eDAO.salvarEmpresa(e);
        }
        else{
            System.err.println("CNPJ invalido");
        }
    }
    
    public List<Empresa> buscarEmpresa()
    {
        return eDAO.buscarEmpresa();
    }
    
    public Empresa buscarEmpresa(String cnpj)
    {
        return eDAO.buscarEmpresa(cnpj);
    }
    
    public void mostrarDados(List<Empresa> lstE)
    {
        if(lstE.isEmpty())
        {
            System.out.println("Nao ha empresas cadastradas");
            return;
        }
        
        for(Empresa e : lstE)
        {
            dadosEmpresa(e);
            System.out.println("**********");
            
            for(Pessoa p : e.getLstPessoas())
            {
                dadosPessoa(p);
                System.out.println("-----------------");
            }
        }
        
    }
    
    public void mostrarDados(Empresa e)
    {
        if(e == null)
        {
            System.out.println("Nenhuma empresa cadastrada");
            return;
        }
        dadosEmpresa(e);
        System.out.println("*********************");
        if(!e.getLstPessoas().isEmpty())
        {
            for(Pessoa p : e.getLstPessoas())
            {
                dadosPessoa(p);
                System.out.println("------------");
            }
        }
    }
    
    public void dadosEmpresa(Empresa e)
    {
        System.out.println("CNPJ: " + e.getCNPJ());
        System.out.println("Nome: " + e.getNome());
    }
     
    public void dadosPessoa(Pessoa p)
    {
        System.out.println("Nome: " + p.getNome());
        System.out.println("CPF: " + p.getCpf());
        System.out.println("Data de Nascimento: " + p.getDataNascimento());

    }
    
    
    
}
