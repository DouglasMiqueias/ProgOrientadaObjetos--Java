package prova.prj_dmam_cadastroempresas.dao;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import prova.prj_dmam_cadastroempresas.arquivos.EscreverArquivo;
import prova.prj_dmam_cadastroempresas.arquivos.LerArquivo;
import prova.prj_dmam_cadastroempresas.objetos.Empresa;
import prova.prj_dmam_cadastroempresas.objetos.Pessoa;
public class EmpresaDAO 
{
    private final String ARQUIVO = "c:\\Empresa.txt";
    private final boolean MANTER = true;
    
    public void salvarEmpresa(Empresa e)
    {
        String dados = "" + e.getCNPJ() + "," + e.getNome();
        List<Pessoa> lstPessoas = e.getLstPessoas();
        for(Pessoa pessoa : lstPessoas)
        {
            dados = dados + ";" + pessoa.getNome() + ", " + pessoa.getCpf() + ", " + pessoa.getDataNascimento() + "; ";
        }
        new EscreverArquivo().escrever(ARQUIVO, dados, MANTER);
    }
    
    public List<Empresa> buscarEmpresa()
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null) return null;
        
        List<Empresa> lstE = new ArrayList<>();
        
        try
        {
            while(br.ready())
            {
                String itensString[] = br.readLine().split(";");
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setCNPJ(objEmpresa[0]);
                    e.setNome(objEmpresa[1]);
                    
                    lstE.add(e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new ArrayList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        
                        for(String item : itensString)
                        {
                            Pessoa p = new Pessoa();
                            String objPessoa[] = item.split(",");
                            p.setNome(objPessoa[0].trim());
                            p.setCpf(objPessoa[1].trim());
                            p.setDataNascimento(objPessoa[2].trim());
                            
                            lstPessoas.add(p);
                        }
                        e.setLstPessoas(lstPessoas);
                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        return lstE;
    }
    
    public Empresa buscarEmpresa(String cnpj)
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null) return null;
        
        Map<String, Empresa> map = new HashMap<>();
        
        try
        {
            while(br.ready())
            {
                String itensString[] = br.readLine().split(";");
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setCNPJ(objEmpresa[0]);
                    e.setNome(objEmpresa[1]);
                    
                    map.put(e.getCNPJ(), e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new ArrayList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        
                        for(String item : itensString)
                        {
                            Pessoa p = new Pessoa();
                            String objPessoa[] = item.split(", ");
                            p.setNome(objPessoa[0].trim());
                            p.setCpf(objPessoa[1].trim());
                            p.setDataNascimento(objPessoa[2].trim());
                            
                            lstPessoas.add(p);
                        }
                    }
            }
            
        }
    }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return map.get(cnpj);
    }
}
