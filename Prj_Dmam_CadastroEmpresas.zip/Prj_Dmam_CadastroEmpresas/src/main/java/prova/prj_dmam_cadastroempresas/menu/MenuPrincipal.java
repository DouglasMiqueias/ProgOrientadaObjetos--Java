/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova.prj_dmam_cadastroempresas.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import prova.prj_dmam_cadastroempresas.bo.EmpresaBO;
import prova.prj_dmam_cadastroempresas.objetos.Empresa;
import prova.prj_dmam_cadastroempresas.objetos.Pessoa;

/**
 *
 * @author IFTM
 */
public class MenuPrincipal 
{
    private static Scanner sc = new Scanner(System.in);
    private static EmpresaBO empresaBO = new EmpresaBO(); 
    public static void executar()
    {
        
        int opcao;
        do {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Salvar nova Empresa");
            System.out.println("2. Listar todas as Empresas");
            System.out.println("3. Consultar Empresa por CNPJ");
            System.out.println("4. Sair");
            
            opcao = sc.nextInt();
            sc.nextLine();
            switch(opcao)
            {
                case 1 -> salvarEmpresa();
                case 2 -> listarEmpresas();
                case 3 -> 
                {
                    System.out.print("Digite o CNPJ: ");
                    String cnpj = sc.nextLine();
                    listarEmpresa(cnpj);
                }
                case 4 -> System.out.println("Saindo do programa");
                default -> System.out.println("Opcao invalida, tente novamente");       
            }         
        } while(opcao != 4);
    }
    
    private static void salvarEmpresa()
    {
        System.out.println("=== CADASTRO DE EMPRESA ===");
        Empresa empresa = new Empresa();
        
        System.out.print("Nome da empresa: ");
        empresa.setNome(sc.nextLine());
        
        System.out.print("CNPJ: ");
        empresa.setCNPJ(sc.nextLine());
        
        String resp;
        List<Pessoa> pessoas = new ArrayList<>();
        
        do{
            System.out.println("Deseja adicionar um membro para a empresa " + empresa.getNome() + " ? (s/n): ");
            resp = sc.nextLine();
            
            if(resp.equalsIgnoreCase("s"))
            {
                pessoas.add(lerDadosPessoa());
            }
        } while(resp.equalsIgnoreCase("s"));
        
        empresa.setLstPessoas(pessoas);
        empresaBO.salvarEmpresa(empresa);
    }
    
    private static Pessoa lerDadosPessoa()
    {
        System.out.println("\n=== CADASTRO DE PESSOA ===");
        Pessoa pessoa = new Pessoa();
        
        System.out.print("Nome da pessoa: ");
        pessoa.setNome(sc.nextLine());
        
        System.out.print("CPF: ");
        pessoa.setCpf(sc.nextLine());
        
        System.out.print("Data de Nascimento: ");
        pessoa.setDataNascimento(sc.nextLine());
        
        return pessoa;
    }
    
    public static void listarEmpresas()
    {
        List<Empresa> empresas = empresaBO.buscarEmpresa();
        if(empresas != null)
        {
            empresaBO.mostrarDados(empresas);
        }
    }
    
    private static void listarEmpresa(String cnpj)
    {
        Empresa e = empresaBO.buscarEmpresa(cnpj);
        if(e != null)
        {
            empresaBO.mostrarDados(e);
        }
    }
}
