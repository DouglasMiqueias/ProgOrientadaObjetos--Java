package prova.prj_dmam_cadastroempresas.objetos;

import java.util.List;

public class Empresa 
{
    private String nome;
    private String CNPJ;
    private List<Pessoa> lstPessoas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public List<Pessoa> getLstPessoas() {
        return lstPessoas;
    }

    public void setLstPessoas(List<Pessoa> lstPessoas) {
        this.lstPessoas = lstPessoas;
    }
    
    
}
