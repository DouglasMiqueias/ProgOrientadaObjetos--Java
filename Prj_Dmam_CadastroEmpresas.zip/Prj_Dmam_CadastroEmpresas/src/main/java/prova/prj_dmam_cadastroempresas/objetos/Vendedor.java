package prova.prj_dmam_cadastroempresas.objetos;

public class Vendedor extends Pessoa
{
    private double taxaComissao;

    public double getTaxaComissao() {
        return taxaComissao;
    }

    public void setTaxaComissao(double taxaComissao) {
        this.taxaComissao = taxaComissao;
    }
    
    
    
}
