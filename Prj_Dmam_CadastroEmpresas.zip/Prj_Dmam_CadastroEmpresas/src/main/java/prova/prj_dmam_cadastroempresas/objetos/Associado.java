package prova.prj_dmam_cadastroempresas.objetos;

public class Associado 
{
    private double taxaParticipacaoLucros;

    public double getTaxaParticipacaoLucros() {
        return taxaParticipacaoLucros;
    }

    public void setTaxaParticipacaoLucros(double taxaParticipacaoLucros) {
        this.taxaParticipacaoLucros = taxaParticipacaoLucros;
    }
    
}
