package com.poo.prjexemplolistas.objetos;

import java.util.List;

public class Aluno 
{
    private String nome;
    private String dataNascimento;
    private String cpf;
    private List<Disciplina> lstDisciplinas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public List<Disciplina> getLstDisciplinas() {
        return lstDisciplinas;
    }

    public void setLstDisciplinas(List<Disciplina> lstDisciplinas) {
        this.lstDisciplinas = lstDisciplinas;
    }
    
}
