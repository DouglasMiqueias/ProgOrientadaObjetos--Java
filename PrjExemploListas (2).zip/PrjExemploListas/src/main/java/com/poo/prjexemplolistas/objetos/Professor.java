package com.poo.prjexemplolistas.objetos;

import java.util.List;

public class Professor {
    private String nome;
    private String cpf;
    private String graduacao;
    private List<Disciplina> lstDisciplinas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    public List<Disciplina> getLstDisciplinas() {
        return lstDisciplinas;
    }

    public void setLstDisciplinas(List<Disciplina> lstDisciplinas) {
        this.lstDisciplinas = lstDisciplinas;
    }
    
    
    
    
    
}
