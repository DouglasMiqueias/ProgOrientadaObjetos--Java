/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjexemplosobrecarga;

import com.poo.prjexemplosobrecarga.classes.Teste;

/**
 *
 * @author IFTM
 */
public class PrjExemploSobrecarga {

    public static void main(String[] args) 
    {
        //new Teste();
        //new Teste("20/08/25");
        Teste t = new Teste();
        System.err.println("Resultado = "+ t.somar("5", 5));
        System.out.println("Resultado = "+ t.somar(1.5f, 7));
        System.out.println("Resultado = "+ t.somar(5.2f, 6.4f));
        System.err.println("Resultado = "+ t.somar(1, 2, 3));
        System.err.println("Resultado = "+ t.somar(8, 9));
    }
}
