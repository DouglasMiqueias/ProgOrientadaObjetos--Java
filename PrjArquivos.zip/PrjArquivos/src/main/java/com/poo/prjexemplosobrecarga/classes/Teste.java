package com.poo.prjexemplosobrecarga.classes;

public class Teste 
{
    public Teste()
    {
        System.out.println("Aula de POO - 19/08/25");
    }
    
    public Teste(String data)
    {
        System.out.println("Aula de Poo - "+ data);
    }
    
    public int somar(int num1, int num2)
    {
        return num1 + num2;
    }
    public int somar(int num1, int num2, int num3)
    {
        return num1 + num2 + num3;
    }
    
    public float somar(float num1, float num2)
    {
        return num1 + num2;
    }
    
    public float somar(String num1, float num2)
    {
        return Float.parseFloat(num1) + num2;
    }
    public float somar(float num1, String num2)
    {
        return Float.parseFloat(num2) + num1;
    }
}
