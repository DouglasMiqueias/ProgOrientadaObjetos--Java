/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package prova.prjexemplointerface;

/**
 *
 * @author IFTM
 */
public class PrjExemploInterface {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
