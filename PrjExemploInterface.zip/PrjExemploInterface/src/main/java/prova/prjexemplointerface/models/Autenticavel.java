package prova.prjexemplointerface.models;

public interface Autenticavel 
{
    boolean autenticar(String senha);
    
}
