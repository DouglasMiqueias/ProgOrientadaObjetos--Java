package prova.prjexemplointerface;

public class Autenticar 
{
    
    
}
