package com.mycompany.prjcalculadora_060825.RN;

import com.mycompany.prjcalculadora_060825.objetos.DadosEntrada;
import com.mycompany.prjcalculadora_060825.objetos.DadosSaida;

public class RealizarCalculoAreaTriangulo 
{
    public DadosSaida realizarCalculo(DadosEntrada de)
    {
      CalculaAreaTriangulo calcArea = new CalculaAreaTriangulo();
        
        DadosSaida ds = new DadosSaida();
        calcArea.calculaAreaTrian(de, ds);
        System.out.println("A area do triangulo eh: " + ds.getAreaTriangulo());
        return ds;
    }
}
