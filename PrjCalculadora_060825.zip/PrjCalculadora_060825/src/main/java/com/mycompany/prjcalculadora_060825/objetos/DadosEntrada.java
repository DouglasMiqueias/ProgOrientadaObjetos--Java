/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcalculadora_060825.objetos;

/**
 *
 * @author IFTM
 */
public class DadosEntrada 
{
    private float a;
    private float b;
    private float c;
    private float alturaTriangulo;
    private float baseTriangulo;

    public float getA() {
        return a;
    }

    public void setA(float a) {
        this.a = a;
    }

    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getC() {
        return c;
    }

    public void setC(float c) {
        this.c = c;
    }

    public float getAlturaTriangulo() {
        return alturaTriangulo;
    }

    public void setAlturaTriangulo(float alturaTriangulo) {
        this.alturaTriangulo = alturaTriangulo;
    }

    public float getBaseTriangulo() {
        return baseTriangulo;
    }

    public void setBaseTriangulo(float baseTriangulo) {
        this.baseTriangulo = baseTriangulo;
    }
    
    
}
