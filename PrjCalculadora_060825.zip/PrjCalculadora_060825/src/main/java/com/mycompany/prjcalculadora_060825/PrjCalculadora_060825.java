package com.mycompany.prjcalculadora_060825;

import com.mycompany.prjcalculadora_060825.RN.RealizarCalcEqSegGrau;
import com.mycompany.prjcalculadora_060825.objetos.DadosEntrada;
import com.mycompany.prjcalculadora_060825.RN.RealizarCalculoAreaTriangulo;

public class PrjCalculadora_060825 {

    public static void main(String[] args) {
        
        /*RealizarOperacoes ro = new RealizarOperacoes();
        System.out.println("Soma: "+ ro.somar(20, 7));
        System.out.println("Subtracao "+ ro.subtracao(20, 7));
        System.out.println("Multiplicacao: "+ ro.multiplicacao(20, 7));
        System.out.println("Divisao: " + ro.divisao(20, 7));*/
        
        DadosEntrada de = new DadosEntrada();
        
        de.setA(1);
        de.setB(5);
        de.setC(6);
        
        RealizarCalcEqSegGrau calcEqSegGrau = new RealizarCalcEqSegGrau();
        calcEqSegGrau.realizarCalculo(de);
        
        de.setBaseTriangulo(5);
        de.setAlturaTriangulo(7);
        
        RealizarCalculoAreaTriangulo areaTriang = new RealizarCalculoAreaTriangulo();     
        areaTriang.realizarCalculo(de);
    }
}
