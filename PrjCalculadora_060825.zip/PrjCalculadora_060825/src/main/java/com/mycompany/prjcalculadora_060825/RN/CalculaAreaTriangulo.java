/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcalculadora_060825.RN;

import com.mycompany.prjcalculadora_060825.objetos.DadosEntrada;
import com.mycompany.prjcalculadora_060825.objetos.DadosSaida;

/**
 *
 * @author IFTM
 */
public class CalculaAreaTriangulo 
{

    public void calculaAreaTrian(DadosEntrada de, DadosSaida ds)
    {
        ds.setAreaTriangulo((de.getBaseTriangulo()*de.getAlturaTriangulo()) / 2);        
    }
    
}
