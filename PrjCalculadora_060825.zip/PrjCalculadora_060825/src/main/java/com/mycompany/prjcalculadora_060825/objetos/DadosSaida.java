/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcalculadora_060825.objetos;

/**
 *
 * @author IFTM
 */
public class DadosSaida 
{
    private float delta;
    private float x1l;
    private float x2l;
    private float xV;
    private float yV;
    private float areaTriangulo;

    public float getAreaTriangulo() {
        return areaTriangulo;
    }

    public void setAreaTriangulo(float areaTriangulo) {
        this.areaTriangulo = areaTriangulo;
    }

    public float getDelta() {
        return delta;
    }

    public void setDelta(float delta) {
        this.delta = delta;
    }

    public float getX1l() {
        return x1l;
    }

    public void setX1l(float x1l) {
        this.x1l = x1l;
    }

    public float getX2l() {
        return x2l;
    }

    public void setX2l(float x2l) {
        this.x2l = x2l;
    }

    public float getxV() {
        return xV;
    }

    public void setxV(float xV) {
        this.xV = xV;
    }

    public float getyV() {
        return yV;
    }

    public void setyV(float yV) {
        this.yV = yV;
    }
    
    
    
}
