package com.mycompany.prjcalculadora_060825.RN.menu;

import java.util.Scanner;

public class MenuPrincipal {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int opcao = -1;

        while (opcao != 0) {
            System.out.println("Menu:");
            System.out.println("1 - Fazer 1");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 -> System.out.println("Fazer 1");
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida.");
            }
        }

        scanner.close();
    }
}
