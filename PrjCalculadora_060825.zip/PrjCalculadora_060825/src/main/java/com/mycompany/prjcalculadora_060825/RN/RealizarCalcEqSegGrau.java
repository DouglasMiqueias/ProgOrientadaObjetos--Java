package com.mycompany.prjcalculadora_060825.RN;

import com.mycompany.prjcalculadora_060825.objetos.DadosEntrada;
import com.mycompany.prjcalculadora_060825.objetos.DadosSaida;

public class RealizarCalcEqSegGrau 
{
    public DadosSaida realizarCalculo(DadosEntrada de)
    {
        CalculadoraEqSegGrau calcSegGrau = new CalculadoraEqSegGrau();
        
        DadosSaida ds = new DadosSaida();

        calcSegGrau.calcularDelta(de, ds);
        System.out.println("Delta: "+ ds.getDelta());
        
        if(ds.getDelta() < 0)
        {
            System.err.println("Delta menor que 0. Nao ha raizes reais.");
        }else{
            calcSegGrau.calcularX1L(de, ds);
            calcSegGrau.calcularX2L(de, ds);
            System.out.println("X1L: "+ ds.getX1l());
            System.out.println("X2L: "+ ds.getX2l());
        }      
        calcSegGrau.calcularXv(de, ds);
        calcSegGrau.calcularYv(de, ds);
        System.out.println("Xv: "+ ds.getxV());
        System.out.println("Yv: "+ ds.getyV());
        
        return ds;
    }
}
