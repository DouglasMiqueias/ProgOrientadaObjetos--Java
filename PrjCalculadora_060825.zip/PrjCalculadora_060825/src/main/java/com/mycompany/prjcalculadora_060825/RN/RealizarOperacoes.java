package com.mycompany.prjcalculadora_060825.RN;

public class RealizarOperacoes
{
    public float somar(float n1, float n2)
    {
        return n1 + n2;
    }
    
    public float subtracao(float n1, float n2)
    {
        return n1 - n2;
    }
    public float multiplicacao(float n1, float n2)
    {
        return n1 * n2;
    }
    public float divisao(float n1, float n2)
    {
        return n1 / n2;
    }
}
